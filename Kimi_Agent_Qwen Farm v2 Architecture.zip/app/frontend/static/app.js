import * as geo from './geo.js';

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const state = {
  user: null, summary: null, devices: [], aiStatus: null, earth: null,
  selectedZone: null, selectedDevice: null, currentView: 'overview',
  deferredInstall: null, confirmCallback: null, pollTimer: null, toastTimer: null,
};

class APIError extends Error {
  constructor(message, status) { super(message); this.status = status; }
}

function node(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function toast(message) {
  const element = $('#toast');
  element.textContent = message;
  element.classList.add('visible');
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => element.classList.remove('visible'), 3600);
}

function cookie(name) {
  const entry = document.cookie.split('; ').find((value) => value.startsWith(`${name}=`));
  return entry ? decodeURIComponent(entry.slice(name.length + 1)) : '';
}

async function api(path, options = {}) {
  const method = options.method || 'GET';
  const headers = { Accept: 'application/json', ...(options.headers || {}) };
  if (options.body) headers['Content-Type'] = 'application/json';
  if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) {
    headers['X-CSRF-Token'] = cookie('__Host-qwen_csrf') || cookie('qwen_csrf');
  }
  let response;
  try {
    response = await fetch(path, { ...options, method, headers, credentials: 'same-origin' });
  } catch {
    setConnection(false);
    throw new APIError('Network unavailable. Cached app shell remains available; live data is unchanged.', 0);
  }
  if (response.status === 204) return null;
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401 && !path.startsWith('/api/auth/login')) showAuthentication();
    throw new APIError(data.detail || `Request failed (${response.status})`, response.status);
  }
  setConnection(true);
  return data;
}

function setConnection(online) {
  const element = $('#connection-state');
  element.classList.toggle('offline', !online);
  element.lastElementChild.textContent = online ? 'LIVE' : 'OFFLINE';
  $('#footer-status').textContent = online ? 'SYSTEM READY' : 'NETWORK OFFLINE';
}

function showAuthentication() {
  state.user = null;
  clearInterval(state.pollTimer);
  $('#app-shell').hidden = true;
  $('#auth-view').hidden = false;
  $('#login-form').hidden = false;
  $('#bootstrap-form').hidden = true;
  $('#login-form input[name="password"]').value = '';
}

function showApplication(user) {
  state.user = user;
  $('#auth-view').hidden = true;
  $('#app-shell').hidden = false;
  $('#operator-name').textContent = `${user.username.toUpperCase()} / ${user.role.toUpperCase()}`;
  navigate('overview');
  Promise.all([loadSummary(), loadDevices(), loadAIStatus()]).catch((error) => toast(error.message));
  clearInterval(state.pollTimer);
  state.pollTimer = setInterval(() => {
    if (state.user && !document.hidden) loadSummary({ quiet: true }).catch(() => {});
  }, 20000);
  initializeGlobe();
}

async function initializeSession() {
  try {
    const setup = await api('/api/auth/bootstrap-status');
    if (setup.required) {
      $('#login-form').hidden = true;
      $('#bootstrap-form').hidden = false;
      $('#bootstrap-token-label').hidden = !setup.token_required;
      $('#bootstrap-form input[name="bootstrap_token"]').required = setup.token_required;
      return;
    }
    try {
      const user = await api('/api/auth/session');
      if (user) showApplication(user);
    } catch (error) {
      if (error.status !== 401) $('#auth-error').textContent = error.message;
    }
  } catch (error) {
    $('#auth-error').textContent = error.message;
  }
}

async function handleAuthSubmit(event, bootstrap) {
  event.preventDefault();
  const form = event.currentTarget;
  const button = form.querySelector('button[type="submit"]');
  const values = Object.fromEntries(new FormData(form));
  $('#auth-error').textContent = '';
  button.disabled = true;
  try {
    const user = await api(bootstrap ? '/api/auth/bootstrap' : '/api/auth/login', {
      method: 'POST', body: JSON.stringify(values),
    });
    form.reset();
    showApplication(user);
  } catch (error) {
    $('#auth-error').textContent = error.message;
  } finally {
    button.disabled = false;
  }
}

function navigate(view) {
  state.currentView = view;
  $$('.view').forEach((section) => { section.hidden = section.id !== `view-${view}`; });
  $$('.nav-item').forEach((button) => {
    const active = button.dataset.view === view;
    button.classList.toggle('active', active);
    if (active) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });
  if (view === 'ai') {
    loadAIStatus().catch((error) => toast(error.message));
    loadChat().catch((error) => toast(error.message));
  }
  if (view === 'devices') loadDevices().catch((error) => toast(error.message));
  if (view === 'overview') setTimeout(() => { drawTrend(); drawWaterGauge(); }, 0);
}

async function loadSummary({ quiet = false } = {}) {
  try {
    state.summary = await api('/api/dashboard/summary');
    state.devices = state.summary.devices;
    renderSummary();
  } catch (error) {
    if (!quiet) toast(error.message);
    throw error;
  }
}

async function loadDevices() {
  state.devices = await api('/api/iot/devices');
  renderDevices();
  if (state.summary) {
    state.summary.devices = state.devices;
    renderZones();
    updateGlobeMarkers();
  }
}

function formatMetric(value, unit) {
  return value === null || value === undefined ? '—' : `${Number(value).toFixed(1)}${unit}`;
}

function renderSummary() {
  const { metrics, alerts, generated_at: generatedAt } = state.summary;
  $('#kpi-online').textContent = `${metrics.online_devices}/${metrics.total_devices}`;
  $('#kpi-total').textContent = metrics.total_devices ? 'Authenticated sensor identities' : 'No enrolled nodes';
  $('#kpi-temperature').textContent = formatMetric(metrics.average_temperature_c, '°');
  $('#kpi-soil').textContent = formatMetric(metrics.average_soil_moisture_pct, '%');
  $('#kpi-alerts').textContent = String(metrics.active_alerts).padStart(2, '0');
  $('#kpi-updated').textContent = `Updated ${new Date(generatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  $('#water-value').textContent = formatMetric(metrics.average_water_level_pct, '%');
  $('#alert-count').textContent = `${alerts.length} OPEN`;
  renderZones(); renderAlerts(alerts); drawWaterGauge(); drawTrend(); updateGlobeMarkers();
}

function currentDevices() {
  if (state.selectedDevice) return state.devices.filter((device) => device.id === state.selectedDevice);
  if (state.selectedZone) return state.devices.filter((device) => device.zone === state.selectedZone);
  return state.devices;
}

function renderZones() {
  const host = $('#zone-list');
  host.replaceChildren();
  const all = node('button', `zone-button${!state.selectedZone && !state.selectedDevice ? ' active' : ''}`);
  all.dataset.zone = '';
  all.append(node('span', 'status-dot'), node('span', '', 'All farm nodes'), node('span', '', String(state.devices.length).padStart(2, '0')));
  host.append(all);
  const zones = [...new Set(state.devices.map((device) => device.zone))].sort();
  $('#zone-count').textContent = String(zones.length).padStart(2, '0');
  zones.forEach((zone) => {
    const devices = state.devices.filter((device) => device.zone === zone);
    const online = devices.some((device) => device.online && device.active);
    const button = node('button', `zone-button${state.selectedZone === zone && !state.selectedDevice ? ' active' : ''}`);
    button.dataset.zone = zone;
    const label = node('span');
    label.append(node('b', '', zone), node('small', '', `${devices.length} NODE${devices.length === 1 ? '' : 'S'}`));
    button.append(node('span', `status-dot${online ? '' : ' off'}`), label, node('span', '', `${devices.filter((device) => device.online).length}/${devices.length}`));
    host.append(button);
  });
  if (!state.devices.length) host.append(node('p', 'empty-state', 'Enroll an ESP32 node to establish your first zone.'));
}

function renderAlerts(alerts) {
  const host = $('#alert-list');
  host.replaceChildren();
  if (!alerts.length) {
    host.append(node('p', 'empty-state', 'No alerts. The monitoring policy is active.'));
    return;
  }
  alerts.forEach((alert) => {
    const item = node('article', `alert-item ${alert.severity}`);
    const content = node('div');
    content.append(node('b', '', alert.device_name), node('p', '', alert.message));
    const time = node('time', '', new Date(alert.created_at).toLocaleString());
    content.append(time);
    item.append(node('span', 'alert-severity'), content);
    host.append(item);
  });
}

function selectZone(zone) {
  state.selectedZone = zone || null;
  state.selectedDevice = null;
  renderZones(); drawTrend(); updateReadout();
  if (zone) {
    const device = state.devices.find((item) => item.zone === zone);
    if (device) state.earth?.focus(device.id);
  }
}

function updateReadout() {
  const host = $('#globe-readout');
  host.replaceChildren();
  const selected = state.devices.find((device) => device.id === state.selectedDevice);
  const title = selected ? selected.name : state.selectedZone || 'All farm nodes';
  const scope = selected ? `${selected.zone} / ${selected.id}` : `${currentDevices().length} nodes in scope`;
  host.append(node('span', '', 'SELECTED SCOPE'), node('b', '', title), node('small', '', scope));
  $('#trend-scope').textContent = `${title.toUpperCase()} / LAST 100`;
}

function updateGlobeMarkers() {
  const alertDeviceIds = new Set((state.summary?.alerts || []).map((alert) => alert.device_id));
  state.devices.forEach((device) => { geo.CITY[device.id] = [device.longitude, device.latitude]; });
  const markers = state.devices.map((device) => ({
    city: device.id, v: device.online ? 65 : 25,
    level: device.online && !alertDeviceIds.has(device.id) ? 'safe' : 'warn',
  }));
  state.earth?.setMarkers(markers);
}

async function initializeGlobe() {
  if (state.earth) return;
  try {
    const { globe } = await import('./globe.js');
    state.earth = await globe($('#globe'), {
      markers: [], routes: [], spin: 0.025,
      onPick: (marker) => {
        state.selectedDevice = marker.city;
        state.selectedZone = null;
        renderZones(); drawTrend(); updateReadout();
        state.earth?.focus(marker.city);
      },
    });
    $('#globe .globe-fallback').hidden = true;
    updateGlobeMarkers();
  } catch (error) {
    $('#sw-status').textContent = `3D FALLBACK: ${error instanceof Error ? error.message : 'UNAVAILABLE'}`;
  }
}

function canvasContext(canvas) {
  const rect = canvas.getBoundingClientRect();
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  const width = Math.max(1, Math.round(rect.width * ratio));
  const height = Math.max(1, Math.round(rect.height * ratio));
  if (canvas.width !== width || canvas.height !== height) { canvas.width = width; canvas.height = height; }
  const context = canvas.getContext('2d');
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
  return { context, width: rect.width, height: rect.height };
}

function cssColor(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

function drawWaterGauge() {
  const canvas = $('#water-gauge');
  if (!canvas || canvas.offsetParent === null) return;
  const { context, width, height } = canvasContext(canvas);
  const value = state.summary?.metrics.average_water_level_pct;
  const cx = width / 2, cy = height * 0.77, radius = Math.min(width * 0.35, 82);
  context.clearRect(0, 0, width, height);
  context.lineWidth = 8; context.lineCap = 'round';
  context.strokeStyle = cssColor('--border-default');
  context.beginPath(); context.arc(cx, cy, radius, Math.PI, Math.PI * 2); context.stroke();
  if (value !== null && value !== undefined) {
    context.strokeStyle = value < 20 ? cssColor('--state-critical') : cssColor('--state-active');
    context.beginPath(); context.arc(cx, cy, radius, Math.PI, Math.PI + Math.PI * Math.min(100, value) / 100); context.stroke();
  }
  context.font = '11px "Geist Mono"'; context.fillStyle = cssColor('--text-tertiary'); context.textAlign = 'center';
  context.fillText('0', cx - radius, cy + 17); context.fillText('100', cx + radius, cy + 17);
}

function drawTrend() {
  const canvas = $('#trend-chart');
  if (!canvas || canvas.offsetParent === null || !state.summary) return;
  const deviceIds = new Set(currentDevices().map((device) => device.id));
  const readings = state.summary.readings.filter((reading) => deviceIds.has(reading.device_id));
  $('#trend-empty').hidden = readings.length > 0;
  const { context, width, height } = canvasContext(canvas);
  context.clearRect(0, 0, width, height);
  if (!readings.length) return;
  const pad = { left: 34, right: 16, top: 18, bottom: 25 };
  const w = width - pad.left - pad.right, h = height - pad.top - pad.bottom;
  context.font = '11px "Geist Mono"'; context.fillStyle = cssColor('--text-tertiary'); context.strokeStyle = cssColor('--border-default'); context.lineWidth = 1;
  [0, .25, .5, .75, 1].forEach((step) => {
    const y = pad.top + h * step;
    context.beginPath(); context.moveTo(pad.left, y); context.lineTo(width - pad.right, y); context.stroke();
    context.textAlign = 'right'; context.fillText(String(Math.round(100 - step * 100)), pad.left - 8, y + 3);
  });
  const drawLine = (key, color, maximum) => {
    context.strokeStyle = cssColor(color); context.lineWidth = 2; context.lineJoin = 'round'; context.beginPath();
    readings.forEach((reading, index) => {
      const x = pad.left + (readings.length === 1 ? w / 2 : index / (readings.length - 1) * w);
      const y = pad.top + h * (1 - Math.max(0, Math.min(maximum, reading[key])) / maximum);
      index ? context.lineTo(x, y) : context.moveTo(x, y);
    });
    context.stroke();
  };
  drawLine('temperature_c', '--state-active', 50);
  drawLine('soil_moisture_pct', '--state-safe', 100);
  context.fillStyle = cssColor('--text-tertiary'); context.textAlign = 'left';
  context.fillText(new Date(readings[0].recorded_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), pad.left, height - 7);
  context.textAlign = 'right';
  context.fillText(new Date(readings.at(-1).recorded_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), width - pad.right, height - 7);
}

function renderDevices() {
  const body = $('#device-table');
  body.replaceChildren();
  $('#device-count').textContent = `${state.devices.length} DEVICE${state.devices.length === 1 ? '' : 'S'}`;
  $('#device-empty').classList.toggle('visible', state.devices.length === 0);
  state.devices.forEach((device) => {
    const row = node('tr');
    const identity = node('td'); identity.dataset.label = 'Node';
    identity.append(node('b', '', device.name), node('small', '', device.id));
    const zone = node('td', '', device.zone); zone.dataset.label = 'Zone';
    const coordinates = node('td', 'mono', `${device.latitude.toFixed(3)}, ${device.longitude.toFixed(3)}`); coordinates.dataset.label = 'Coordinates';
    const seen = node('td', '', device.last_seen ? new Date(device.last_seen).toLocaleString() : 'Never'); seen.dataset.label = 'Last seen';
    const status = node('td', device.online ? 'pos' : 'dim', !device.active ? 'DISABLED' : device.online ? 'ONLINE' : 'OFFLINE'); status.dataset.label = 'Status';
    const action = node('td'); action.dataset.label = 'Action';
    if (device.active) {
      const button = node('button', 'button secondary', 'Disable');
      button.dataset.deactivate = device.id;
      action.append(button);
    }
    row.append(identity, zone, coordinates, seen, status, action);
    body.append(row);
  });
}

async function enrollDevice(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const values = Object.fromEntries(new FormData(form));
  values.latitude = Number(values.latitude); values.longitude = Number(values.longitude);
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true; $('#device-error').textContent = '';
  try {
    const result = await api('/api/iot/devices', { method: 'POST', body: JSON.stringify(values) });
    $('#device-dialog').close(); form.reset();
    $('#device-token').value = result.token; $('#copy-status').textContent = '';
    $('#token-dialog').showModal();
    await Promise.all([loadDevices(), loadSummary()]);
  } catch (error) {
    $('#device-error').textContent = error.message;
  } finally { button.disabled = false; }
}

function askConfirmation(title, message, callback) {
  $('#confirm-title').textContent = title; $('#confirm-message').textContent = message;
  state.confirmCallback = callback; $('#confirm-dialog').showModal();
}

async function loadAIStatus() {
  state.aiStatus = await api('/api/ai/status');
  const label = state.aiStatus.loaded ? 'LOADED' : state.aiStatus.enabled ? 'READY' : 'OFFLINE';
  ['#ai-summary-state', '#ai-runtime-state'].forEach((selector) => {
    $(selector).textContent = label; $(selector).classList.toggle('offline', !state.aiStatus.enabled);
  });
  $('#ai-summary-detail').textContent = state.aiStatus.detail;
  $('#ai-runtime-detail').textContent = state.aiStatus.detail;
}

function appendChatMessage(role, content, error = false) {
  $('#chat-log .chat-empty')?.remove();
  const message = node('article', `chat-message ${role}${error ? ' error' : ''}`);
  message.append(node('small', '', role === 'user' ? 'OPERATOR' : error ? 'RUNTIME NOTICE' : 'LOCAL LLAMA'), node('div', '', content));
  $('#chat-log').append(message);
  $('#chat-log').scrollTop = $('#chat-log').scrollHeight;
}

async function loadChat() {
  const history = await api('/api/ai/history');
  $('#chat-log').replaceChildren();
  if (!history.length) {
    const empty = node('div', 'chat-empty');
    empty.append(node('b', '', 'Ask about farm operations'), node('p', '', 'Responses are generated locally only when the model runtime and adapter weights are installed. Telemetry is never invented.'));
    $('#chat-log').append(empty);
  } else history.forEach((message) => appendChatMessage(message.role, message.content));
}

async function sendChat(event) {
  event.preventDefault();
  const input = $('#chat-input');
  const text = input.value.trim();
  if (!text) return;
  const button = $('#chat-send'); button.disabled = true;
  appendChatMessage('user', text); input.value = '';
  try {
    const response = await api('/api/ai/chat', { method: 'POST', body: JSON.stringify({ message: text }) });
    appendChatMessage('assistant', response.message.content);
    await loadAIStatus();
  } catch (error) {
    appendChatMessage('assistant', error.message, true);
  } finally { button.disabled = false; input.focus(); }
}

async function copyToken() {
  const field = $('#device-token');
  try {
    await navigator.clipboard.writeText(field.value);
    $('#copy-status').textContent = 'Copied to clipboard.';
  } catch {
    field.focus(); field.select();
    $('#copy-status').textContent = 'Select and copy the highlighted token.';
  }
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  try { localStorage.setItem('qwen-theme', theme); } catch { /* preference is optional */ }
  dispatchEvent(new Event('kit:theme'));
  setTimeout(() => { drawTrend(); drawWaterGauge(); }, 0);
}

function bindEvents() {
  $('#login-form').addEventListener('submit', (event) => handleAuthSubmit(event, false));
  $('#bootstrap-form').addEventListener('submit', (event) => handleAuthSubmit(event, true));
  $$('.nav-item').forEach((button) => button.addEventListener('click', () => navigate(button.dataset.view)));
  $$('[data-navigate]').forEach((button) => button.addEventListener('click', () => navigate(button.dataset.navigate)));
  $('#refresh-button').addEventListener('click', async () => {
    $('#refresh-button').disabled = true;
    try { await Promise.all([loadSummary(), loadAIStatus()]); toast('Operations synchronized'); }
    catch (error) { toast(error.message); }
    finally { $('#refresh-button').disabled = false; }
  });
  $('#logout-button').addEventListener('click', async () => {
    try { await api('/api/auth/logout', { method: 'POST' }); } catch { /* local session is cleared regardless */ }
    showAuthentication();
  });
  $('#theme-button').addEventListener('click', () => applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));
  $('#zone-list').addEventListener('click', (event) => {
    const button = event.target.closest('[data-zone]'); if (button) selectZone(button.dataset.zone);
  });
  $('#register-device-button').addEventListener('click', () => { $('#device-error').textContent = ''; $('#device-dialog').showModal(); });
  $('#device-form').addEventListener('submit', enrollDevice);
  $('#copy-token-button').addEventListener('click', copyToken);
  $('#device-table').addEventListener('click', (event) => {
    const button = event.target.closest('[data-deactivate]'); if (!button) return;
    const device = state.devices.find((item) => item.id === button.dataset.deactivate);
    askConfirmation('Disable device?', `${device.name} will immediately lose ingest access. Historical telemetry is preserved.`, async () => {
      try { await api(`/api/iot/devices/${encodeURIComponent(device.id)}`, { method: 'DELETE' }); await loadSummary(); toast('Device access revoked'); }
      catch (error) { toast(error.message); }
    });
  });
  $('#confirm-action').addEventListener('click', async () => {
    const callback = state.confirmCallback; state.confirmCallback = null; $('#confirm-dialog').close();
    if (callback) await callback();
  });
  $$('[data-close]').forEach((button) => button.addEventListener('click', () => $(`#${button.dataset.close}`).close()));
  $$('dialog').forEach((dialog) => dialog.addEventListener('click', (event) => {
    if (event.target === dialog && dialog.id !== 'token-dialog') dialog.close();
  }));
  $('#chat-form').addEventListener('submit', sendChat);
  $('#chat-input').addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) $('#chat-form').requestSubmit();
  });
  $('#clear-chat-button').addEventListener('click', () => askConfirmation('Clear AI history?', 'This permanently removes your local chat history. Model weights and settings are unchanged.', async () => {
    try { await api('/api/ai/history', { method: 'DELETE' }); await loadChat(); toast('Local chat history cleared'); }
    catch (error) { toast(error.message); }
  }));
  addEventListener('resize', () => { drawTrend(); drawWaterGauge(); });
  addEventListener('online', () => setConnection(true)); addEventListener('offline', () => setConnection(false));
  addEventListener('beforeinstallprompt', (event) => { event.preventDefault(); state.deferredInstall = event; $('#install-button').hidden = false; });
  $('#install-button').addEventListener('click', async () => {
    if (!state.deferredInstall) return;
    state.deferredInstall.prompt(); await state.deferredInstall.userChoice;
    state.deferredInstall = null; $('#install-button').hidden = true;
  });
  setInterval(() => { $('#clock').textContent = new Date().toLocaleTimeString([], { hour12: false }); }, 1000);
}

async function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) { $('#sw-status').textContent = 'PWA UNSUPPORTED'; return; }
  if (!window.isSecureContext) { $('#sw-status').textContent = 'HTTPS REQUIRED'; return; }
  try {
    await navigator.serviceWorker.register('/sw.js', { scope: '/' });
    $('#sw-status').textContent = 'OFFLINE SHELL READY';
  } catch { $('#sw-status').textContent = 'PWA CACHE UNAVAILABLE'; }
}

try { applyTheme(localStorage.getItem('qwen-theme') || 'dark'); } catch { applyTheme('dark'); }
bindEvents();
initializeSession();
registerServiceWorker();
