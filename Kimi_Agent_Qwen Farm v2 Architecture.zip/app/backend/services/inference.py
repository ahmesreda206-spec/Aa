from __future__ import annotations

import asyncio
import threading
from pathlib import Path

from ..config import get_settings

settings = get_settings()


class LocalLlamaService:
    """Lazy, serialized inference keeps GPU memory and request use predictable."""

    def __init__(self) -> None:
        self._model = None
        self._tokenizer = None
        self._torch = None
        self._load_lock = threading.Lock()
        self._inference_lock = threading.Lock()

    @property
    def loaded(self) -> bool:
        return self._model is not None

    def status(self) -> dict[str, str | bool]:
        if not settings.ai_enabled:
            detail = "Local inference is disabled; set QWEN_AI_ENABLED=true after installing the AI runtime."
        elif self.loaded:
            detail = "Base model and LoRA adapter are loaded locally."
        else:
            detail = "Inference is enabled; the model loads on the first chat request."
        return {
            "enabled": settings.ai_enabled,
            "loaded": self.loaded,
            "model": "Llama 14B",
            "adapter": Path(settings.ai_adapter_path).name,
            "detail": detail,
        }

    def _load(self) -> None:
        if self.loaded:
            return
        with self._load_lock:
            if self.loaded:
                return
            try:
                import torch
                from peft import PeftModel
                from transformers import AutoModelForCausalLM, AutoTokenizer
            except ImportError as exc:
                raise RuntimeError("Install requirements-ai.txt to enable local inference") from exc
            base_path = Path(settings.ai_base_path)
            adapter_path = Path(settings.ai_adapter_path)
            if not (base_path / "config.json").is_file():
                raise RuntimeError(f"Base model configuration not found at {base_path}")
            if not (adapter_path / "adapter_model.safetensors").is_file():
                raise RuntimeError(f"LoRA weights not found at {adapter_path}")
            dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
            tokenizer = AutoTokenizer.from_pretrained(base_path, local_files_only=True)
            tokenizer.chat_template = (adapter_path / "chat_template.jinja").read_text(encoding="utf-8")
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token
            base = AutoModelForCausalLM.from_pretrained(
                base_path,
                torch_dtype=dtype,
                device_map="auto" if torch.cuda.is_available() else None,
                local_files_only=True,
            )
            self._model = PeftModel.from_pretrained(base, adapter_path, local_files_only=True)
            self._model.eval()
            self._tokenizer = tokenizer
            self._torch = torch

    def _generate(self, history: list[dict[str, str]]) -> str:
        self._load()
        assert self._model is not None and self._tokenizer is not None and self._torch is not None
        with self._inference_lock:
            messages = [{"role": "system", "content": "You are Qwen Farm's concise, safety-aware local agronomy and operations assistant. State uncertainty and never invent telemetry."}, *history[-12:]]
            prompt = self._tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            encoded = self._tokenizer(prompt, return_tensors="pt", add_special_tokens=False)
            encoded = {key: value.to(self._model.device) for key, value in encoded.items()}
            with self._torch.inference_mode():
                output = self._model.generate(
                    **encoded,
                    max_new_tokens=settings.ai_max_new_tokens,
                    do_sample=settings.ai_temperature > 0,
                    temperature=settings.ai_temperature if settings.ai_temperature > 0 else None,
                    top_p=0.9 if settings.ai_temperature > 0 else None,
                    pad_token_id=self._tokenizer.pad_token_id,
                    eos_token_id=self._tokenizer.eos_token_id,
                )
            generated = output[0][encoded["input_ids"].shape[1]:]
            return self._tokenizer.decode(generated, skip_special_tokens=True).strip()

    async def generate(self, history: list[dict[str, str]]) -> str:
        return await asyncio.to_thread(self._generate, history)


llama_service = LocalLlamaService()
