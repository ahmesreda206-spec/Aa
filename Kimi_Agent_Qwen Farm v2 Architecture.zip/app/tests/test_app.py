from __future__ import annotations

import os
from pathlib import Path

TEST_ROOT = Path(__file__).parent
os.environ["QWEN_ENVIRONMENT"] = "test"
os.environ["QWEN_DATABASE_URL"] = f"sqlite:///{TEST_ROOT / 'test-qwen.db'}"
os.environ["QWEN_SECRET_KEY"] = "test-only-secret-with-sufficient-entropy-1234567890"
os.environ["QWEN_COOKIE_SECURE"] = "false"
os.environ["QWEN_ALLOWED_HOSTS"] = "testserver"
os.environ["QWEN_AI_ENABLED"] = "false"

from fastapi.testclient import TestClient  # noqa: E402

from backend.main import app  # noqa: E402


def csrf(client: TestClient) -> dict[str, str]:
    return {"X-CSRF-Token": client.cookies.get("qwen_csrf")}


def test_secure_full_stack_workflow() -> None:
    database = TEST_ROOT / "test-qwen.db"
    for suffix in ("", "-shm", "-wal"):
        Path(f"{database}{suffix}").unlink(missing_ok=True)

    with TestClient(app) as client:
        assert client.get("/health").status_code == 200
        setup = client.get("/api/auth/bootstrap-status")
        assert setup.json() == {"required": True, "token_required": False}

        response = client.post(
            "/api/auth/bootstrap",
            json={"username": "farm.admin", "password": "correct-horse-battery-staple"},
        )
        assert response.status_code == 201
        assert response.json()["role"] == "admin"
        assert client.cookies.get("qwen_session")
        assert client.cookies.get("qwen_csrf")
        assert client.post("/api/auth/bootstrap", json={"username": "second.admin", "password": "another-password"}).status_code == 409

        enrolled = client.post(
            "/api/iot/devices",
            headers=csrf(client),
            json={"name": "North greenhouse", "zone": "North", "latitude": 31.23, "longitude": 121.47},
        )
        assert enrolled.status_code == 201
        token = enrolled.json()["token"]
        device_id = enrolled.json()["device"]["id"]
        assert "token" not in client.get("/api/iot/devices").json()[0]

        reading = {
            "device_id": device_id,
            "temperature_c": 24.6,
            "humidity_pct": 63.2,
            "soil_moisture_pct": 44,
            "water_level_pct": 76,
            "battery_v": 3.91,
            "rssi_dbm": -59,
        }
        assert client.post("/api/iot/telemetry", json=reading).status_code == 422
        assert client.post("/api/iot/telemetry", json=reading, headers={"X-IoT-Token": "wrong"}).status_code == 422
        assert client.post("/api/iot/telemetry", json=reading, headers={"X-IoT-Token": token}).status_code == 201
        assert client.post("/api/iot/telemetry", json={**reading, "soil_moisture_pct": 900}, headers={"X-IoT-Token": token}).status_code == 422
        assert client.post("/api/iot/telemetry", json={**reading, "unexpected": True}, headers={"X-IoT-Token": token}).status_code == 422

        dashboard = client.get("/api/dashboard/summary")
        assert dashboard.status_code == 200
        assert dashboard.json()["metrics"]["online_devices"] == 1
        assert dashboard.json()["metrics"]["average_temperature_c"] == 24.6
        assert dashboard.json()["metrics"]["active_alerts"] == 0

        ai_status = client.get("/api/ai/status")
        assert ai_status.status_code == 200
        assert ai_status.json()["enabled"] is False
        unavailable = client.post("/api/ai/chat", headers=csrf(client), json={"message": "Check irrigation"})
        assert unavailable.status_code == 503
        assert "traceback" not in unavailable.text.lower()

        assert client.post("/api/auth/logout").status_code == 403
        assert client.post("/api/auth/logout", headers=csrf(client)).status_code == 204
        assert client.get("/api/dashboard/summary").status_code == 401

        page = client.get("/")
        assert page.status_code == 200
        assert "script-src 'self'" in page.headers["content-security-policy"]
        assert "unsafe-inline" not in page.headers["content-security-policy"]
        assert page.headers["x-content-type-options"] == "nosniff"
        assert client.get("/static/app.js").status_code == 200
        assert client.get("/manifest.json").status_code == 200
        assert client.get("/sw.js").status_code == 200

    for suffix in ("", "-shm", "-wal"):
        Path(f"{database}{suffix}").unlink(missing_ok=True)
