#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <DHT.h>
#include <time.h>
#include "secrets.h"

constexpr uint8_t DHT_PIN = 4;
constexpr uint8_t SOIL_PIN = 34;
constexpr uint8_t WATER_PIN = 35;
constexpr uint8_t BATTERY_PIN = 36;
constexpr uint32_t SAMPLE_INTERVAL_MS = 60000;
constexpr int SOIL_DRY_RAW = 3200;
constexpr int SOIL_WET_RAW = 1350;
constexpr int WATER_EMPTY_RAW = 0;
constexpr int WATER_FULL_RAW = 3000;
constexpr float BATTERY_DIVIDER_RATIO = 2.0f;

DHT dht(DHT_PIN, DHT22);
WiFiClientSecure tlsClient;
uint32_t lastSample = 0;

float percentageFromAdc(int raw, int low, int high) {
  const float value = 100.0f * static_cast<float>(raw - low) / static_cast<float>(high - low);
  return constrain(value, 0.0f, 100.0f);
}

bool syncClock() {
  configTime(0, 0, "pool.ntp.org", "time.nist.gov");
  for (uint8_t attempt = 0; attempt < 30; ++attempt) {
    time_t now = time(nullptr);
    if (now > 1700000000) return true;
    delay(500);
  }
  return false;
}

bool connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return true;
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  for (uint8_t attempt = 0; attempt < 40 && WiFi.status() != WL_CONNECTED; ++attempt) delay(500);
  return WiFi.status() == WL_CONNECTED;
}

String isoTimestamp() {
  time_t now = time(nullptr);
  struct tm utc;
  gmtime_r(&now, &utc);
  char buffer[25];
  strftime(buffer, sizeof(buffer), "%Y-%m-%dT%H:%M:%SZ", &utc);
  return String(buffer);
}

void sendTelemetry() {
  if (!connectWiFi()) return;
  const float temperature = dht.readTemperature();
  const float humidity = dht.readHumidity();
  if (!isfinite(temperature) || !isfinite(humidity)) return;

  JsonDocument document;
  document["device_id"] = IOT_DEVICE_ID;
  document["recorded_at"] = isoTimestamp();
  document["temperature_c"] = serialized(String(temperature, 2));
  document["humidity_pct"] = serialized(String(humidity, 2));
  document["soil_moisture_pct"] = serialized(String(percentageFromAdc(analogRead(SOIL_PIN), SOIL_WET_RAW, SOIL_DRY_RAW), 2));
  document["water_level_pct"] = serialized(String(percentageFromAdc(analogRead(WATER_PIN), WATER_EMPTY_RAW, WATER_FULL_RAW), 2));
  document["battery_v"] = serialized(String((analogRead(BATTERY_PIN) / 4095.0f) * 3.3f * BATTERY_DIVIDER_RATIO, 3));
  document["rssi_dbm"] = WiFi.RSSI();

  String body;
  serializeJson(document, body);
  tlsClient.setCACert(ROOT_CA);
  HTTPClient https;
  https.setConnectTimeout(10000);
  https.setTimeout(15000);
  if (!https.begin(tlsClient, API_URL)) return;
  https.addHeader("Content-Type", "application/json");
  https.addHeader("X-IoT-Token", IOT_TOKEN);
  const int status = https.POST(body);
  if (status < 200 || status >= 300) {
    Serial.printf("Telemetry rejected: HTTP %d\n", status);
  }
  https.end();
}

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);
  analogSetPinAttenuation(SOIL_PIN, ADC_11db);
  analogSetPinAttenuation(WATER_PIN, ADC_11db);
  analogSetPinAttenuation(BATTERY_PIN, ADC_11db);
  dht.begin();
  if (!connectWiFi()) {
    Serial.println("Wi-Fi connection failed");
    return;
  }
  if (!syncClock()) Serial.println("Clock synchronization failed");
}

void loop() {
  const uint32_t now = millis();
  if (now - lastSample >= SAMPLE_INTERVAL_MS) {
    lastSample = now;
    sendTelemetry();
  }
  delay(100);
}
