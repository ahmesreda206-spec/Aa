from fastapi import Request
from sqlalchemy.orm import Session

from ..models import AuditLog


def audit(db: Session, request: Request, actor: str, action: str) -> None:
    db.add(AuditLog(actor=actor, action=action, request_id=request.state.request_id))
